| id  | name                 |
|-----|----------------------|
| 1   | Grand Piano          |
| 2   | Bright Piano         |
| 3   | Honky-tonk Piano     |
| 4   | MIDI Grand Piano     |
| 5   | Harpsichord          |
| 6   | Electric Piano 1     |
| 7   | Electric Piano 2     |
| 8   | Electric Grand Piano |
| 9   | Clavi                |
| 10  | Drawbar Organ        |
| 11  | Percussive Organ     |
| 12  | Rock Organ           |
| 13  | Church Organ         |
| 14  | Reed Organ           |
| 15  | Accordion            |
| 16  | Tango Accordion      |
| 17  | Harmonica            |
| 18  | Strings              |
| 19  | Strings 2            |
| 20  | Synth Strings 1      |
| 21  | Synth Strings 2      |
| 22  | Marcato Strings      |
| 23  | Tremolo Strings      |
| 24  | Pizzicato Strings    |
| 25  | Violin               |
| 26  | Viola                |
| 27  | Cello                |
| 28  | Contrabass           |
| 29  | Orchestral Harp      |
| 30  | Orchestra Hit        |
| 31  | Nylon Guitar         |
| 32  | Steel Guitar         |
| 33  | Jazz Guitar          |
| 34  | Clean Guitar         |
| 35  | Muted Guitar         |
| 36  | Overdriven Guitar    |
| 37  | Distortion Guitar    |
| 38  | Guitar Harmonics     |
| 39  | Acoustic Bass        |
| 40  | Finger Bass          |
| 41  | Pick Bass            |
| 42  | Fretless Bass        |
| 43  | Slap Bass 1          |
| 44  | Slap Bass 2          |
| 45  | Synth Bass 1         |
| 46  | Synth Bass 2         |
| 47  | Choir Aahs           |
| 48  | Voice Oohs           |
| 49  | Synth Voice          |
| 50  | Trumpet              |
| 51  | Muted Trumpet        |
| 52  | Trombone             |
| 53  | French Horn          |
| 54  | Tuba                 |
| 55  | Brass Section        |
| 56  | Synth Brass          |
| 57  | Funky Analog         |
| 58  | Techno Brass         |
| 59  | Synth Brass 1        |
| 60  | Synth Brass 2        |
| 61  | Tenor Sax            |
| 62  | Alto Sax             |
| 63  | Soprano Sax          |
| 64  | Baritone Sax         |
| 65  | Oboe                 |
| 66  | Clarinet             |
| 67  | English Horn         |
| 68  | Bassoon              |
| 69  | Flute                |
| 70  | Piccolo              |
| 71  | Pan Flute            |
| 72  | Recorder             |
| 73  | Blown Bottle         |
| 74  | Shakuhachi           |
| 75  | Whistle              |
| 76  | Ocarina              |
| 77  | Funky Lead           |
| 78  | Portatone            |
| 79  | UnderHeim            |
| 80  | Square Lead          |
| 81  | Sawtooth Lead        |
| 82  | Calliope Lead        |
| 83  | Chiff Lead           |
| 84  | Charang Lead         |
| 85  | Voice Lead           |
| 86  | Fifths Lead          |
| 87  | Bass & Lead          |
| 88  | Fantasia             |
| 89  | Symbiont             |
| 90  | Sweet Heaven         |
| 91  | Dream Heaven         |
| 92  | New Age Pad          |
| 93  | Warm Pad             |
| 94  | Poly Synth Pad       |
| 95  | Choir Pad            |
| 96  | Bowed Pad            |
| 97  | Metallic Pad         |
| 98  | Halo Pad             |
| 99  | Sweep Pad            |
| 100 | Vibraphone           |
| 101 | Marimba              |
| 102 | Xylophone            |
| 103 | Steel Drums          |
| 104 | Celesta              |
| 105 | Music Box            |
| 106 | Tubular Bells        |
| 107 | Timpani              |
| 108 | Glockenspiel         |
| 109 | Tinkle Bell          |
| 110 | Agogo                |
| 111 | Woodblock            |
| 112 | Taiko Drum           |
| 113 | Melodic Tom          |
| 114 | Synth Drum           |
| 115 | Reverse Cymbal       |
| 116 | Sitar                |
| 117 | Dulcimer             |
| 118 | Banjo                |
| 119 | Shamisen             |
| 120 | Koto                 |
| 121 | Kalimba              |
| 122 | Bagpipe              |
| 123 | Fiddle               |
| 124 | Shanai               |
| 125 | Rain                 |
| 126 | Sound Track          |
| 127 | Crystal              |
| 128 | Atmosphere           |
| 129 | Brightness           |
| 130 | Goblins              |
| 131 | Echoes               |
| 132 | Sci-Fi               |
| 133 | Fret Noise           |
| 134 | Breath Noise         |
| 135 | Seashore             |
| 136 | Bird Tweet           |
| 137 | Telephone Ring       |
| 138 | Helicopter           |
| 139 | Applause             |
| 140 | Gunshot              |
