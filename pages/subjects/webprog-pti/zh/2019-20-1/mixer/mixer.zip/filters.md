| id | name                     |
|----|--------------------------|
| 1  | Compressor               |
| 2  | XCompressor              |
| 3  | Delay                    |
| 4  | Reverb                   |
| 5  | Equalizer                |
| 6  | FFT                      |
| 7  | Gate                     |
| 8  | Pitch                    |
| 9  | Tune                     |
| 10 | Low-frequency oscillator |
