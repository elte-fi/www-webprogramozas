| id | name            | filename     | balance | volume | filters                             |
|----|-----------------|--------------|---------|--------|-------------------------------------|
| 1  | Drum 1          | drum1.wav    | -10     | 35     | ["XCompressor"]                     |
| 2  | Drum 2          | drum2.wav    | 15      | 40     | ["Compressor","FFT"]                |
| 3  | Lead guitar     | lead.wav     | -20     | 60     | ["Compressor","Equalizer","Reverb"] |
| 4  | Acoustic guitar | acoustic.wav | 20      | 30     | ["Pitch","Reverb"]                  |
| 5  | Keyboard        | piano.wav    | 3       | 75     | ["FFT"]                             |
